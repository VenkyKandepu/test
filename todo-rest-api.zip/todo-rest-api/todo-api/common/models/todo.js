'use strict';

module.exports = function(Todo) {

};
